﻿namespace KingsGambit
{
    public class King
    {
        public King(string name)
        {
            this.Name = name;
        }

        public string Name { get; private set; }
    }
}