﻿namespace BirthdayCelebrations.Models
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
