﻿namespace BirthdayCelebrations.Models
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
