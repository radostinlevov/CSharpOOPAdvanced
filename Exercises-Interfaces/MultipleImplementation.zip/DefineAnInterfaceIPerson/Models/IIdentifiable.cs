﻿namespace DefineAnInterfaceIPerson.Models
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
