﻿namespace DefineAnInterfaceIPerson.Models
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
