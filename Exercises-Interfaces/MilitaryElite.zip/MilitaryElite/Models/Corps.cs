﻿namespace MilitaryElite.Models
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}