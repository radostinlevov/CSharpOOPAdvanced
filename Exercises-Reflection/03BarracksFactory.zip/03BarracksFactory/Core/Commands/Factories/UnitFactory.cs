﻿namespace _03BarracksFactory.Core.Factories
{
    using System;
    using Contracts;
    using System.Reflection;
    using System.Linq;

    public class UnitFactory : IUnitFactory
    {
        public IUnit CreateUnit(string unitType)
        {
            var type = Assembly.GetExecutingAssembly().DefinedTypes.First(t => t.Name == unitType);
            IUnit unit = Activator.CreateInstance(type) as IUnit;

            return unit;
        }
    }
}
