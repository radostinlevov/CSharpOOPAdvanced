﻿namespace _03BarracksFactory.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
