﻿namespace TrafficLights
{
    public enum TrafficLight
    {
        Red, 
        Green,
        Yellow
    }
}
